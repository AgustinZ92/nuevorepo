import java.io.*;
import java.util.ArrayList;

public class GestorLibreria {

    private ArrayList<Libro> inventario = new ArrayList<>();
    private final String ARCHIVO = "inventario.dat";

    public GestorLibreria() {
        cargarDatos();
    }

    public void agregarLibro(Libro l) {
        inventario.add(l);
        guardarDatos();
        System.out.println("Libro agregado correctamente.");
    }

    public void mostrarLibros() {
        if (inventario.isEmpty()) {
            System.out.println("No hay libros en el inventario.");
            return;
        }
        for (Libro l : inventario) {
            System.out.println(l);
        }
    }

    public Libro buscarLibro(String titulo) {
        for (Libro l : inventario) {
            if (l.getTitulo().equalsIgnoreCase(titulo)) return l;
        }
        return null;
    }

    public void eliminarLibro(String titulo) {
        Libro l = buscarLibro(titulo);
        if (l != null) {
            inventario.remove(l);
            guardarDatos();
            System.out.println("Libro eliminado correctamente.");
        } else {
            System.out.println("No existe un libro con ese título.");
        }
    }

    public void modificarLibro(String titulo, java.util.Scanner sc) {
        Libro l = buscarLibro(titulo);
        if (l == null) {
            System.out.println("No existe un libro con ese título.");
            return;
        }

        System.out.print("Nuevo título: ");
        l.setTitulo(sc.nextLine());
        System.out.print("Nuevo autor: ");
        l.setAutor(sc.nextLine());
        System.out.print("Nuevo género: ");
        l.setGenero(sc.nextLine());
        System.out.print("Nuevo precio: ");
        l.setPrecio(Double.parseDouble(sc.nextLine()));
        System.out.print("Nueva cantidad: ");
        l.setCantidad(Integer.parseInt(sc.nextLine()));

        guardarDatos();
        System.out.println("Libro modificado correctamente.");
    }

    @SuppressWarnings("unchecked")
    public void cargarDatos() {
        try {
            FileInputStream fis = new FileInputStream(ARCHIVO);
            ObjectInputStream ois = new ObjectInputStream(fis);
            inventario = (ArrayList<Libro>) ois.readObject();
            ois.close();
        } catch (Exception e) {
            inventario = new ArrayList<>();
        }
    }

    public void guardarDatos() {
        try {
            FileOutputStream fos = new FileOutputStream(ARCHIVO);
            ObjectOutputStream oos = new ObjectOutputStream(fos);
            oos.writeObject(inventario);
            oos.close();
        } catch (Exception e) {
            System.out.println("Error guardando datos.");
        }
    }
}
