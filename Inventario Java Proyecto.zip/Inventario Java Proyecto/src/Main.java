import java.util.Scanner;

public class Main {

    public static void main(String[] args) {

        Scanner sc = new Scanner(System.in);
        GestorLibreria gestor = new GestorLibreria();

        int opcion = 0;

        while(opcion != 5) {
            System.out.println("\n===== GESTOR DE LIBRERÍA =====");
            System.out.println("1. Agregar libro");
            System.out.println("2. Mostrar libros");
            System.out.println("3. Modificar libro");
            System.out.println("4. Eliminar libro");
            System.out.println("5. Salir");
            System.out.print("Seleccione una opción: ");

            try {
                opcion = Integer.parseInt(sc.nextLine());
            } catch (Exception e) {
                System.out.println("Opción inválida.");
                continue;
            }

            switch(opcion) {
                case 1:
                    System.out.print("Título: ");
                    String t = sc.nextLine();
                    System.out.print("Autor: ");
                    String a = sc.nextLine();
                    System.out.print("Género: ");
                    String g = sc.nextLine();
                    System.out.print("Precio: ");
                    double p = Double.parseDouble(sc.nextLine());
                    System.out.print("Cantidad: ");
                    int c = Integer.parseInt(sc.nextLine());

                    gestor.agregarLibro(new Libro(t,a,g,p,c));
                    break;

                case 2:
                    gestor.mostrarLibros();
                    break;

                case 3:
                    System.out.print("Ingrese el título del libro a modificar: ");
                    gestor.modificarLibro(sc.nextLine(), sc);
                    break;

                case 4:
                    System.out.print("Ingrese el título del libro a eliminar: ");
                    gestor.eliminarLibro(sc.nextLine());
                    break;

                case 5:
                    System.out.println("Saliendo... Guardando datos.");
                    break;

                default:
                    System.out.println("Opción inválida.");
            }
        }

        sc.close();
    }
}
