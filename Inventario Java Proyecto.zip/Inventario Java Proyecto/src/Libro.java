import java.io.Serializable;

public class Libro implements Serializable {
    private String titulo;
    private String autor;
    private String genero;
    private double precio;
    private int cantidad;

    public Libro(String titulo, String autor, String genero, double precio, int cantidad) {
        this.titulo = titulo;
        this.autor = autor;
        this.genero = genero;
        this.precio = precio;
        this.cantidad = cantidad;
    }

    public String getTitulo() { return titulo; }
    public void setTitulo(String t) { titulo = t; }

    public String getAutor() { return autor; }
    public void setAutor(String a) { autor = a; }

    public String getGenero() { return genero; }
    public void setGenero(String g) { genero = g; }

    public double getPrecio() { return precio; }
    public void setPrecio(double p) { precio = p; }

    public int getCantidad() { return cantidad; }
    public void setCantidad(int c) { cantidad = c; }

    @Override
    public String toString() {
        return "Titulo: " + titulo + " | Autor: " + autor + " | Genero: " + genero +
                " | Precio: $" + precio + " | Stock: " + cantidad;
    }
}
